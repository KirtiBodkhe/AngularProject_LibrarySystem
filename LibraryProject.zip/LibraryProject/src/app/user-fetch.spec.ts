import { UserFetch } from './user-fetch';

describe('UserFetch', () => {
  it('should create an instance', () => {
    expect(new UserFetch()).toBeTruthy();
  });
});
