import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-component',
  templateUrl: './member-component.component.html',
  styleUrls: ['./member-component.component.css']
})
export class MemberComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
