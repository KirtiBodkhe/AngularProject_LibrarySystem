export class UserFetch {
    id:string;
    Book_title:string;
    Book_auther:string;
    NumberOfBooks:string
}
