import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AuthorisedSideNavServiceService } from '../authorised-side-nav-service.service';


@Component({
  selector: 'app-admin-component',
  templateUrl: './admin-component.component.html',
  styleUrls: ['./admin-component.component.css']
})
export class AdminComponentComponent implements OnInit {
@ViewChild('menu') menu: ElementRef;

  constructor(public sideNavService: AuthorisedSideNavServiceService) { }

  ngOnInit() {
  }
  toggleMenu() {
    this.menu.nativeElement.click();
}

closeMenu() {
    const isMenuOpen = this.menu.nativeElement.getAttribute('aria-expanded') === 'true';
    if (isMenuOpen) {
        this.menu.nativeElement.click();
    }
}
}
