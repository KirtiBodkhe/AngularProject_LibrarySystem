import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router,private http:HttpClient) { }

  ngOnInit(): void {
  }
  OnLogin(form){
console.log(form.userName);
//this.route.navigateByUrl("/admin");
  }

//   onCreatePost(postData: { userName: string; password: any }) {
//     // Send Http request
//     this.http
//       .post(
//         ' http://localhost:3000/posts',
//         postData
//       )
//       .subscribe(responseData => {
//         console.log(responseData);
//       });

//       //console.log(form.userName);
// this.route.navigate([('/admin')]);
//   }
}
