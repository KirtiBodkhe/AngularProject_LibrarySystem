import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-main-component',
  templateUrl: './main-component.component.html',
  styleUrls: ['./main-component.component.css']
})
export class MainComponentComponent implements OnInit {
//   title = 'Angular Form Validation Tutorial';
//   angForm: FormGroup;
//   constructor(private fb: FormBuilder) {
//    this.createForm();
//  }
//   createForm() {
//    this.angForm = this.fb.group({
//       name: ['', Validators.required ],
//       address: ['', Validators.required ]
//    });
//  }

  ngOnInit() {
   }

}
